def hash(elem):
    value = 0
    for char in elem._element:
        value += ord(char)

    return value

class Vertex:
    __slots__ = '_element'

    def __init__(self, x):
        self._element = x

    def __hash__(self):
        return hash(self)

    def get_value(self):
        return self._element

    def __str__(self):
        return str(self._element)


class Edge:
    __slots__ = '_origin', '_destination', '_element'

    def __init__(self, u, v, x):
        self._origin = u
        self._destination = v
        self._element = x

    def get_origin(self):
        return self._origin

    def endpoints(self):
        return self._origin, self._destination

    def opposite(self, v):
        return self._destination if v is self._origin else self._origin

    def element(self):
        return self._element

    def __hash__(self):
        return hash((self._origin, self._destination))

    def __str__(self):
        return "{}---{}".format(self._origin, self._destination)


class Graph:

    def __init__(self, directed=False):
        self._outgoing = {}
        self._incoming = {} if directed else self._outgoing

    def is_directed(self):
        return self._incoming is not self._outgoing

    def vertex_count(self):
        return len(self._outgoing)

    def vertices(self):
        return self._outgoing.keys()

    def edge_count(self):
        total = sum(len(self._outgoing[hash(v)]) for v in self._outgoing)
        return total if self.is_directed() else total // 2

    def edges(self):
        result = set()
        for secondary_map in self._outgoing.values():
            result.update(secondary_map.values())
        return result

    def get_edge(self, u, v):
        return self._outgoing[hash(u)].get(v)

    def degree(self, v, outgoing=True):
        adj = self._outgoing if outgoing else self._incoming
        return len(adj[hash(v)])

    def incident_edges(self, v, outgoing=True):
        adj = self._outgoing if outgoing else self._incoming
        for edge in adj[hash(v)].values():
            yield edge

    def insert_vertex(self, x=None):
        v = Vertex(x)
        if self._outgoing.get(hash(v)) is None:
            self._outgoing[hash(v)] = {}
            if self.is_directed():
                self._incoming[hash(v)] = {}
            return v
        else:
            return v


    def insert_edge(self, u, v, x=None):
        e = Edge(u, v, x)
        self._outgoing[hash(u)][hash(v)] = e
        self._incoming[hash(v)][hash(u)] = e
