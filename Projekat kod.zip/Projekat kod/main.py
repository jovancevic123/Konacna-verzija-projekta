import os
import time
from Parser import *
from Trie import *
from Graph import *
from Stack import *
from bs4 import BeautifulSoup
from Levenshtein import distance
import pickle
from colorama import Fore, Back, Style


rootdir ='C:/Users/Joca/PycharmProjects/Projekat2ASP-jedan-trie/python-3.8.3-docs-html'
vertex_dictionary = {}
words_dictionary = {}
dictionary_for_autocomplete = {}
all_words = []
parser = Parser()
root = TrieNode('*')
root_title = TrieNode('*')
graph = Graph(True)
final_results_list = []
binary_operators = ['and', 'or', 'not']
matrix_for_phrases = {}


class context_object:
    def __init__(self, context, index, word_length):
        self.context = context
        self.index = index
        self.word_length = word_length

class result_object:
    def __init__(self, path, points, context=""):
        self.path = path
        self.points = points
        self.context = context

    def __eq__(self, other):
        return self.path == other.path

def bubble_sort(results):
    swapped = True
    while swapped:
        swapped = False
        for i in range(len(results) - 1):
            if results[i].points < results[i + 1].points:
                results[i], results[i + 1] = results[i + 1], results[i]
                swapped = True
    return results

def get_file_name(path):
    tokens = path.rsplit('\\', 1)
    result = tokens[1].split('.')
    return result[0]

def get_title(path):
    file = open(path, encoding='utf8')
    soup = BeautifulSoup(file.read(), 'html.parser')
    title = soup.title
    return title.string

def get_context(link, word):
    words = words_dictionary[link]
    index = 0
    ret_str = ""
    i = 0
    if title_bool:
        title = get_title(link)
        title_tokens = title.split(' ')
        for t in title_tokens:
            if t.lower() == word.lower():
                ret_str += "\u001b[31m" + t + "\u001b[37m" + ' '
            else:
                ret_str += t + ' '
        return ret_str

    for w in words:
        w = w.lower()
        if w == word.lower() or w.startswith(word.lower()):
            index = i
            break
        i += 1
    counter = index - 10
    for j in range(21):
        try:
            if word.lower() == words[counter].lower() or words[counter].lower().startswith(word.lower()):

                ret_str += "\u001b[31m" + words[counter][0:len(word)] + "\u001b[37m" + words[counter][len(word):] + " "
            else:
                ret_str += "\u001b[37m" + words[counter] + " "
        except:
            pass
            #ret_str += colored(words[counter], 'red') + " "
            #ret_str += Fore.RED + words[counter] + " "

        counter += 1

    return ret_str

def get_context_for_phrase(link, word):
    content = get_html_content(link)
    index = content.find(word)
    back = index - 1
    front = index + 1
    while content[back] != '\n':
        back -= 1
        if back <= 0:
            break
    while content[front] != '\n':
        front += 1
        if front >= len(content) - 1:
            break
    if index - back <= 5 and index > 51 or index - back > 300:
        back = index - 50
    if front - index <= 5 and index < len(content) - 51 or front - index > 300:
        front = index + 50
    context = content[back:front]
    index = context.find(word)
    ret = change_color_of_word(context_object(context, index, len(word)))
    return ret

def change_color_of_word(context_obj):
    text = context_obj.context
    index = context_obj.index
    length = context_obj.word_length
    res = text[:index - 1] + "\u001b[31m" + text[index:index + length] + "\u001b[37m" + text[-(index + length - index):] + '\n\n'
    return res

def heuristic_graph(graph, dict_of_link_info, word):
    result_list = []
    for link in dict_of_link_info.keys():
        points = 0
        v = vertex_dictionary[link]
        for i in graph.incident_edges(v, True):
            opposite_vertex = i.opposite(v)
            count = dict_of_link_info.get(opposite_vertex.get_value())
            if count is None:
                continue
            points += 1
            points += int(count)
            points += int(dict_of_link_info[link])
        context = get_context(link, word)
        r = result_object(link, points, context)
        result_list.append(r)
    return result_list


def get_html_content(link_path):
    f = open(link_path, encoding='utf-8')
    content = f.read()
    soup = BeautifulSoup(content, 'html.parser')
    text = soup.find_all(text=True)

    output = ''
    blacklist = [
        '[document]',
        'noscript',
        'header',
        'html',
        'meta',
        'head',
        'input',
        'script',
        'li',
        'ul',
        'div',
        'style'
    ]

    for t in text:
        if t.parent.name not in blacklist:
            output += '{} '.format(t)
    return output

def and_binary_operation(first_operand, second_operand):
    result_list = []

    for first in first_operand:
        for second in second_operand:
            if first == second:
                first.points += second.points
                first.context += '\n' + second.context
                result_list.append(first)

    return result_list


def or_binary_operation(first_operand, second_operand):
    result_list = []
    ind = False

    for first in first_operand:
        for second in second_operand:
            ind = False
            if first == second:
                ind = True
                first.points += second.points
                first.context += '\n' + second.context
                result_list.append(first)
                second_operand.remove(second)
        if not ind:
            result_list.append(first)
    for second in second_operand:
        result_list.append(second)

    return result_list


def not_binary_operation(first_operand, second_operand):
    result_list = []
    for first in first_operand:
        if first not in second_operand:
            result_list.append(first)

    return result_list


def calculate_binary_operators(tokens):
    stack = Stack()

    for token in tokens:
        if token.lower() == "and" or token.lower() == "or" or token.lower() == "not":
            stack.push(token)
        else:
            if stack.top() == "and":
                operator = stack.pop()
                first_operand = stack.pop()
                bool, dict_of_link_info = find_prefix(root, token)
                second_operand = heuristic_graph(graph, dict_of_link_info, token)
                result = and_binary_operation(first_operand, second_operand)
                stack.push(result)

            elif stack.top() == "or":
                operator = stack.pop()
                first_operand = stack.pop()
                bool, dict_of_link_info = find_prefix(root, token)
                second_operand = heuristic_graph(graph, dict_of_link_info, token)
                result = or_binary_operation(first_operand, second_operand)
                stack.push(result)

            elif stack.top() == "not":
                operator = stack.pop()
                first_operand = stack.pop()
                bool, dict_of_link_info = find_prefix(root, token)
                second_operand = heuristic_graph(graph, dict_of_link_info, token)
                result = not_binary_operation(first_operand, second_operand)
                stack.push(result)

            else:
                bool, dict_of_link_info = find_prefix(root, token)
                results_1 = heuristic_graph(graph, dict_of_link_info, token)
                stack.push(results_1)
    final_results_list = stack.pop()

    return final_results_list



def list_for_phrase_query(tokens):
    stack = Stack()
    for token in tokens:
        if len(stack) == 0:
            bool, dict_of_link_info = find_prefix(root, token)
            results_1 = heuristic_graph(graph, dict_of_link_info, token)
            stack.push(results_1)
        elif len(stack) == 1:
            first_operand = stack.pop()
            bool, dict_of_link_info = find_prefix(root, token)
            second_operand = heuristic_graph(graph, dict_of_link_info, token)
            result = and_binary_operation(first_operand, second_operand)
            stack.push(result)
    ret_list = stack.pop()
    return ret_list


def is_query_binary(tokens):
    for token in tokens:
        if token in binary_operators:
            return True
    return False


def calculate_ordinary_query(tokens):
    final_results_list = []

    for token in tokens:
        bool, dict_of_link_info = find_prefix(root, token)
        results = heuristic_graph(graph, dict_of_link_info, token)
        for result in results:
            if result not in final_results_list:
                final_results_list.append(result)
            else:
                for r in final_results_list:
                    if r == result:
                        result.points += 1300
                        r.points += result.points
                        r.context += '\n' + result.context

    return final_results_list


def auto_complete_main():
    list = auto_complete(root, user_input)
    list_for_autocomplete = []
    for elem in list:
        points = 0
        str = elem[:-1]
        booli, dict = find_prefix(root, str)
        for d in dict.keys():
            points += dict[d]
        r = result_object(str, points)
        list_for_autocomplete.append(r)
    bubble_sort(list_for_autocomplete)
    return list_for_autocomplete

def offer_similar_meaning(input):
    offer_list = []
    for word in all_words:
        number = distance(word, input)
        boolean, list = find_prefix(root, word)
        if boolean and number <= 2 and len(word) == len(input):
            offer_list.append([word, (100 - number) * len(list), number])

    max = 0
    name = ""
    for elem in offer_list:
        if elem[1] > max:
            max = elem[1]
            name = elem[0]
    return name


def set_up_necessities():
    counter = 0
    for subdir, dirs, files in os.walk(rootdir):
        for file in files:
            if file.endswith('.html'):
                link = os.path.join(subdir, file)
                link_path = link.replace('/', '\\')
                links, words = parser.parse(os.path.join(subdir, file))
                all_words.extend(words)
                words_dictionary[link_path] = words
                title = get_title(link_path)
                title_tokens = title.split(' ')
                for word in words:
                    word = word.lower()
                    # izmena na link path umesto  --- os.path.join(subdir, file)
                    add(root, word, link_path)
                for w in title_tokens:
                    w = w.lower()
                    add(root_title, w, link_path)
                u = graph.insert_vertex(link_path)
                vertex_dictionary[link_path] = u
                for l in links:
                    v = graph.insert_vertex(l)
                    graph.insert_edge(u, v)

def is_query_phrase(user_input):
    if user_input[0] == "'" and user_input[-1] == "'":
        return True
    return False


def calculate_phrase_query(tokens, query, list):
    final_results_list = []
    counter = 0
    for obj in list:
        path = obj.path
        words = words_dictionary[path]
        for i in range(len(words)):
            ind = True
            c = i
            counter = 0
            for j in range(len(tokens)):
                if words[c].lower() == tokens[j].lower():
                    c += 1
                    counter += 1
                    if counter == len(tokens):
                        counter = 0
                        for elem in final_results_list:
                            if elem.path == path:
                                elem.points += 10
                                ind = False
                        if ind:
                            context = func(words, i, len(tokens))
                            # obj = get_context_for_phrase(path, query)
                            r = result_object(path, 10, context)
                            final_results_list.append(r)
    return final_results_list

def func(words, index, len):
    ret_str = ''
    counter = index - 10
    i = 0
    for j in range(21):
        if counter == index:
            while True:
                i += 1
                ret_str += " \u001b[31m" + words[counter] + "\u001b[37m" + " "
                j += 1
                counter += 1
                if i == len:
                    break
        else:
            try:
                ret_str += "\u001b[37m" + words[counter] + " "
            except:
                pass
        counter += 1

    return ret_str


# def calculate_phrase_query(tokens, query, list):
#     final_results_list = []
#     for obj in list:
#         path = obj.path
#         content = get_html_content(path)
#         if content.find(query) != -1:
#             points = 100
#             links, words = parser.parse(path)
#             for link in links:
#                 points += 5
#                 content_link = get_html_content(link)
#                 if content_link.find(query) != -1:
#                     points += 50
#             obj = get_context_for_phrase(path, query)
#             r = result_object(path, points, obj)
#
#             final_results_list.append(r)
#     return final_results_list



def title_query(list, user_input):
    ret_list = []
    # input = user_input[12:]
    tokens = user_input.split(' ')
    input = ""
    for token in tokens:
        if token not in binary_operators:
            input += token + " "

    input = input.strip()
    if input[0] == "'" and input[-1] == "'":
        input = input[1:-1]

    for res in list:
        title = get_title(res.path)
        if input in title.lower():
            ret_list.append(res)
    return ret_list


def serialize_objects():
    with open("trie.pickle", "wb") as pickle_out_trie:
        pickle.dump(root, pickle_out_trie)

    with open("root_title.pickle", "wb") as root_title_out_graph:
        pickle.dump(root_title, root_title_out_graph)

    with open("graph.pickle", "wb") as graph_out:
        pickle.dump(graph, graph_out)

    with open("all_words.pickle", "wb") as pickle_out_all_words:
        pickle.dump(all_words, pickle_out_all_words)

    with open("words_dictionary.pickle", "wb") as pickle_out_words_dictionary:
        pickle.dump(words_dictionary, pickle_out_words_dictionary)

    with open("vertex_dictionary.pickle", "wb") as pickle_out_vertex_dictionary:
        pickle.dump(vertex_dictionary, pickle_out_vertex_dictionary)

def deserialize_objects():
    global root
    with open("trie.pickle", "rb") as pickle_in_trie:
        root = pickle.load(pickle_in_trie)

    global root_title
    with open("root_title.pickle", "rb") as root_title_in_graph:
        root_title = pickle.load(root_title_in_graph)

    with open("graph.pickle", "rb") as graph_in:
        graphhh = pickle.load(graph_in)

    global all_words
    with open("all_words.pickle", "rb") as pickle_in_all_words:
        all_words = pickle.load(pickle_in_all_words)

    global words_dictionary
    with open("words_dictionary.pickle", "rb") as pickle_in_words_dictionary:
        words_dictionary = pickle.load(pickle_in_words_dictionary)

    global vertex_dictionary
    with open("vertex_dictionary.pickle", "rb") as pickle_in_vertex_dictionary:
        vertex_dictionary = pickle.load(pickle_in_vertex_dictionary)

    return graphhh

if __name__ == '__main__':
    time1 = time.perf_counter()
    one_word = False
    title_bool = False
    # set_up_necessities()
    time2 = time.perf_counter()
    graph = deserialize_objects()
    help = root
    print(f"Loaded in {time2 - time1:0.4f} seconds")
    print("\u001b[37m" + "---PRETRAZIVAC---")
    print("Unesite rec koju biste zeleli da pretrazite, frazu(kombinacija reci pod navodnicima) ili vise reci razdvojenih binarnim operatorima.")


    # con = get_context('C:\\Users\\Joca\\PycharmProjects\\Projekat2ASP-jedan-trie\\python-3.8.3-docs-html\\genindex-P.html', 'memory')
    # print(con)
    # links, words = parser.parse('C:\\Users\\Joca\\PycharmProjects\\Projekat2ASP-jedan-trie\\python-3.8.3-docs-html\\bugs.html')
    # print(words)

    while True:
        root = help
        title_bool = False
        one_word = False
        next = True
        user_input = input("Vas upit: ")
        tokens = user_input.split(' ')
        if tokens[0] == 'allintitle:':
            user_input = user_input[11:]
            tokens.remove(tokens[0])
            root = root_title
            title_bool = True

        if len(tokens) == 1:
            one_word = True
            autocomplete = input("Da li zelite autocomplete (>>Da<< , >>Ne<<) : ")
            if autocomplete.lower() == "da":
                list = auto_complete_main()
                for i in range(3):
                    print("{}. {}".format(i+1, list[i].path))
                continue
        if is_query_phrase(user_input):
            query = user_input[1:-1]
            tokens = query.split(' ')
            list = list_for_phrase_query(tokens)
            final_results_list = calculate_phrase_query(tokens, query, list)

        elif is_query_binary(tokens):
            final_results_list = calculate_binary_operators(tokens)
        else:
            final_results_list = calculate_ordinary_query(tokens)

        n = eval(input("Unesite broj rezultata koji zelite da vam se prikaze: "))
        final_results_list = bubble_sort(final_results_list)

        if len(final_results_list) < 1 and one_word:
            print("Za vas upit ne postoji nijedna pretraga ili ih ima malo.")
            suggestion = offer_similar_meaning(user_input)
            answer = input("Da li ste mislili  '" + suggestion + "'(>>Da<< , >>Ne<<) : ")
            if answer.lower() == 'ne':
                continue
            else:
                n = eval(input("Unesite broj rezultata koji zelite da vam se prikaze: "))
                tokens = suggestion.split(' ')
                if is_query_binary(tokens):
                    final_results_list = calculate_binary_operators(tokens)
                else:
                    final_results_list = calculate_ordinary_query(tokens)

                final_results_list = bubble_sort(final_results_list)

        if title_bool:
            final_results_list = title_query(final_results_list, user_input)

        current_result = 0
        while next:
            try:
                for i in range(current_result, n + current_result):
                    print('\033[1m \033[4m' + "{}.".format(i + 1) + "\t Naslov: {} -".format(get_file_name(final_results_list[i].path)) + '\033[0m' + " Poeni: {}".format(final_results_list[i].points))
                    print(final_results_list[i].context)
                    current_result = i + 1

                next_page = input("Da li zelite da vidite narednih n rezultata (>>Da<< , >>Ne<<) : ")
                if next_page.lower() == 'ne':
                    next = False

            except:
                next = False
                print("Nema dovoljnog broja rezultata za vas upit.")

        end = input("Da li zelite da nastavite pretragu (>>Da<< , >>Ne<<) : ")
        if end.lower() == 'ne':
            break

    print("Hvala vam na koriscenju moje aplikacije.")