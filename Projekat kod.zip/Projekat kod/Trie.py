import sys
from typing import Tuple

class TrieNode(object):

    def __init__(self, char: str):
        self.char = char
        self.children = {}
        self.word_finished = False
        self.counter = 1
        self.links = {}

    def print_trie(self, indent="", last=True, stack=""):
        if indent != "":
            stack = stack + self.char

        sys.stdout.write(indent)
        if last:
            sys.stdout.write("┗╾")
            indent += "  "
        else:
            sys.stdout.write("┣╾")
            indent += "┃ "

        sys.stdout.write("{} ({})".format(self.char, self.counter))
        if self.word_finished:
            print(" - {}".format(stack))
        else:
            print()

        for i, c in enumerate(self.children.values()):
            c.print_trie(indent, i == len(self.children) - 1, stack)


def add(root, word: str, path):
    path = path.replace('/', '\\')
    current_node = root
    word = word.lower()
    for char in word:
        found_in_child = False
        if char in current_node.children.keys():
            child = current_node.children[char]
            child.counter += 1
            current_node = child
            found_in_child = True
        if not found_in_child:
            new_node = TrieNode(char)
            current_node.children[char] = new_node
            current_node = new_node

    if current_node.links.get(path) is None:
        current_node.links[path] = 1
    else:
        counter = current_node.links[path]
        counter += 1
        current_node.links[path] = counter
    current_node.word_finished = True

def find_prefix(root, prefix: str):
    node = root
    prefix = prefix.lower()
    if not root.children:
        return False, {}
    for char in prefix:
        char_not_found = True
        if char in node.children.keys():
            child = node.children[char]
            char_not_found = False
            node = child
        if char_not_found:
            return False, {}
    return True, node.links

def auto_complete(root, prefix):
    result_list = []

    node = root
    prefix = prefix.lower()
    if not root.children:
        return False, {}
    for char in prefix:
        char_not_found = True
        if char in node.children.keys():
            child = node.children[char]
            char_not_found = False
            node = child
        if char_not_found:
            return False, {}

    preorder(node, prefix, result_list)
    return result_list

def preorder(node, prefix, result_list):
    for child in node.children.keys():
        new_node = node.children[child]
        preorder(new_node, prefix + child, result_list)
    if node.word_finished:
        result_list.append(prefix + node.char)