class StackError(Exception):
    """
    Klasa modeluje izuzetke vezane za klasu Stack.
    """
    pass

class Stack(object):
    def __init__(self):
        self._data = []

    def __len__(self):
        return len(self._data)

    def is_empty(self):
        if len(self) == 0:
           return True
        return False

    def push(self, element):
       self._data.append(element)

    def top(self):
        if self.is_empty():
            return None
        return self._data[len(self._data)-1]

    def pop(self):
        return self._data.pop()